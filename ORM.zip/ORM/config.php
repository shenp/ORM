<?php
$config['db']=array(
    'db_dns'		=> 'mysql:host=localhost;dbname=test',
    'db_username'	=> 'root',
    'db_passwd'		=> '111111',
);

$config['db_test2']=array(
    'db_dns'		=> 'mysql:host=localhost;dbname=test',
    'db_username'	=> 'root',
    'db_passwd'		=> '111111',
);