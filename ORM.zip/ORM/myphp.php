<?php
require APPDIR.'function.php';

require APPDIR.'config.php';

spl_autoload_register('autoload');