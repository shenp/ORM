<?php
class ORMException extends Exception
{


}