<?php
class Mysql implements Imodel
{
	public function generateSql($oTree)
	{
		
		
	}
	
	
}